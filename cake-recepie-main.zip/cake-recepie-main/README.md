# cake-recepieTIMES FOODRECIPESHOMEMADE CAKE
Homemade Cake Recipe
by TNNUpdated : Sep 24, 2020, 14:23 IST
Avg. Rating
Rate
 Comments (143)
Facebook
Twitter
Pinit
Homemade Cake
Total Time50mPrep Time10 mCalories603
Bookmark
Add To Collection
Wondering how to make a simple cake at home? Try this easy homemade cake recipe today!

If you are looking for cake recipes for beginners, you have to try this homemade cake recipe. What's more? You can make this easy homemade cake recipe in cooker as well! A homemade cake is definitely tastier than the store bought one. But many people believe that making a cake at home is difficult. The best thing about this cake is that you can add any flavour of your choice to suit your palate. If you get the quantities right, this cake will rise, be fluffy and taste delicious. This sponge cake can also be your base for most cream cake recipes that you prepare. One tip that makes this cake perfect is the right way to mix the wet and dry ingredients. It may seem a small thing, but adding both of them together at one go may lead to tiny lumps that may affect the texture of the cake. The trick is to gradually add them together, mixing a little at a time. This cake recipe is easy to follow and you can make your birthday cake out of it and trust us, it will not disappoint you. You can use heart shaped molds for making Valentine's Day or Anniversary Cake. If you want to make this sponge cake creamier, replace half of the milk with condensed milk.

Read more
Ingredients of Homemade Cake

6 Servings
3 cup all purpose flour
4 cup egg
2 teaspoon baking soda
2 teaspoon vanilla essence
1 1/2 cup powdered sugar
1 cup butter
1 cup milk


How to make Homemade Cake
batter
Step 1 Cream together butter-sugar and then blend with beaten eggs
Making a homemade sponge cake was never so easy. Begin by mixing sugar and butter together. Whisk well until light and fluffy with a manual whisker or a fork. Once done, add the beaten eggs and blend well. Beat further so that the mixture turns white and creamy.

cake-batter1
Step 2 Combine flour mix and beaten eggs
Sift together the all-purpose flour and baking soda. It is done to evenly distribute the baking soda in flour. Gradually, add this to the egg mixture. If required, add a little milk and mix till the batter is fluffy and soft. You may not add the entire milk if you feel the consistency of your cake is fine and it pours down like canned condensed milk. Add vanilla essence and blend well. Vanilla essence is important to camouflage the smell of eggs.

Microwave
Step 3 Bake the cake as per your convenience
Sprinkle some maida on a greased baking tin. It will prevent sticking of the cake to the base. You can also line it with a butter paper. Pour the prepared mixture into the tin and place it on a stand in a pressure cooker. Do not add water in the cooker and ensure that the tin does not touch the base of the cooker. You can also keep the baking dish on an inverted steel plate. Increase the flame and pressure cook for two minutes. Now remove the whistle and cook on low flame for 35-40 minutes. If you are using an electric oven, cook at 180 degrees for 30-35 minutes.

image (2)
Step 4 Check with a knife or skewer if it is cooked and serve
Insert a knife or a metal skewer into the cake and if it comes out clean, then the cake is ready. Remove from the oven/cooker and allow to cool on a wire rack.
